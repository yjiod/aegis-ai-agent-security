#!/bin/bash
set -u
INSTALL_DIR="/Library/Application Support/SentinelAgent"
REPORT="$INSTALL_DIR/reports/latest.json"
REPORTING="$INSTALL_DIR/reporting.json"
UPLOAD_STATUS="$INSTALL_DIR/reports/upload-status.json"
PLIST="/Library/LaunchDaemons/com.company.sentinel-agent.plist"
AGENT_SHA="359f2079cf985306b89f6eca0387aecdd7b4114ef849ee9145d22f3c9c715906"
POLICY_SHA="4ebac2abbe3654d048a8af17cf46df3161de336c00d2f5c4c692d90ffeffb832"
BASELINE_SHA="e6d87dba8756aa270a70f423368bf68a44f108a5a299ab2a62c4488ed74a962e"
installed=false; integrity=false; runtime=false
if [[ -f "$INSTALL_DIR/sentinel_agent.py" && -f "$INSTALL_DIR/sentinel-policy.json" && -f "$INSTALL_DIR/sentinel-security-baseline.md" ]]; then installed=true; fi
if [[ "$installed" == true ]] && \
  [[ "$(/usr/bin/shasum -a 256 "$INSTALL_DIR/sentinel_agent.py" | /usr/bin/awk '{print $1}')" == "$AGENT_SHA" ]] && \
  [[ "$(/usr/bin/shasum -a 256 "$INSTALL_DIR/sentinel-policy.json" | /usr/bin/awk '{print $1}')" == "$POLICY_SHA" ]] && \
  [[ "$(/usr/bin/shasum -a 256 "$INSTALL_DIR/sentinel-security-baseline.md" | /usr/bin/awk '{print $1}')" == "$BASELINE_SHA" ]]; then integrity=true; fi
interval="$(/usr/libexec/PlistBuddy -c 'Print :StartInterval' "$PLIST" 2>/dev/null || true)"
run_at_load="$(/usr/libexec/PlistBuddy -c 'Print :RunAtLoad' "$PLIST" 2>/dev/null || true)"
process_type="$(/usr/libexec/PlistBuddy -c 'Print :ProcessType' "$PLIST" 2>/dev/null || true)"
if [[ -f "$PLIST" ]] && /bin/launchctl print system/com.company.sentinel-agent >/dev/null 2>&1 && [[ "$interval" == 3600 ]] && [[ "$run_at_load" == true ]] && [[ "$process_type" == Background ]]; then runtime=true; fi
python_bin="$(command -v python3 2>/dev/null || true)"
if [[ -z "$python_bin" ]]; then
  /usr/bin/printf '%s\n' "{\"SentinelInstalled\":$installed,\"SentinelIntegrityValid\":$integrity,\"SentinelLaunchDaemonHealthy\":$runtime,\"SentinelReportingConfigured\":false,\"SentinelReportingHealthy\":false,\"SentinelPolicyVersion\":\"missing\",\"SentinelReportValid\":false,\"SentinelScanRecent\":false,\"SentinelCriticalFindings\":0,\"SentinelHighFindings\":0}"
  exit 0
fi
"$python_bin" - "$INSTALL_DIR/sentinel-policy.json" "$REPORT" "$REPORTING" "$UPLOAD_STATUS" "$installed" "$integrity" "$runtime" <<'PY'
import hmac, json, pathlib, stat, sys, time
from urllib.parse import urlsplit
policy_path,report_path,reporting_path,upload_status_path=map(pathlib.Path,sys.argv[1:5])
installed,integrity,runtime=(value=="true" for value in sys.argv[5:8])
policy="missing"; recent=False; report_valid=False; reporting_configured=False; reporting_healthy=False; configured_host=""; critical=0; high=0
try:
    info=reporting_path.stat(); value=json.loads(reporting_path.read_text()); parsed=urlsplit(value.get("report_url","")); token=value.get("report_token",""); secret=value.get("signing_secret",""); keys=value.get("policy_verification_keys",[])
    fields={"schema","report_url","report_token","signing_secret","policy_verification_keys"}; schema=value.get("schema"); contract=(schema=="sentinel.reporting/v2" and set(value)==fields) or (schema=="sentinel.reporting/v3" and set(value)==fields|{"device_id"} and isinstance(value.get("device_id"),str) and len(value["device_id"])==12 and all(char in "0123456789abcdef" for char in value["device_id"]))
    reporting_configured=not reporting_path.is_symlink() and stat.S_ISREG(info.st_mode) and not info.st_mode&0o077 and info.st_uid==0 and contract and parsed.scheme=="https" and bool(parsed.hostname) and not parsed.username and not parsed.password and not parsed.query and not parsed.fragment and 32<=len(token)<=4096 and 32<=len(secret)<=4096 and not hmac.compare_digest(token,secret) and isinstance(keys,list) and 1<=len(keys)<=5 and all(isinstance(key,str) and 32<=len(key)<=4096 for key in keys) and len(keys)==len(set(keys)) and token not in keys and secret not in keys
    if reporting_configured: configured_host=parsed.hostname.lower().rstrip(".")
except (OSError,ValueError,TypeError): pass
try:
    status=json.loads(upload_status_path.read_text()); age=int(time.time())-status.get("last_success",0)
    reporting_healthy=reporting_configured and set(status)=={"schema","status","last_success","collector_host"} and status.get("schema")=="sentinel.upload-status/v1" and status.get("status")=="accepted" and status.get("collector_host")==configured_host and type(status.get("last_success")) is int and 0<=age<86400
except (OSError,ValueError,TypeError): pass
try:
    value=json.loads(policy_path.read_text()); policy=str(value.get("version","missing"))
except (OSError,ValueError,TypeError): pass
try:
    report=json.loads(report_path.read_text()); scanned=int(report.get("scanned_at",0)); age=int(time.time())-scanned
    findings=report.get("findings",[]); summary=report.get("summary",{}); severities=("critical","high","medium","low")
    actual={severity:sum(isinstance(item,dict) and item.get("severity")==severity for item in findings) for severity in severities} if isinstance(findings,list) else {}
    valid_findings=isinstance(findings,list) and len(findings)<=10000 and all(isinstance(item,dict) and item.get("severity") in severities and all(isinstance(item.get(key),str) for key in ("kind","path","message")) for item in findings)
    report_valid=report.get("schema")=="sentinel.report/v1" and report.get("agent_version")=="0.52.0" and report.get("policy_version")==policy and isinstance(report.get("device_id"),str) and len(report["device_id"])==12 and all(char in "0123456789abcdef" for char in report["device_id"]) and type(report.get("scanned_at")) is int and valid_findings and isinstance(summary,dict) and all(type(summary.get(severity)) is int and summary[severity]==actual.get(severity) for severity in severities)
    if report_valid: recent=0<=age<86400; critical=actual["critical"]; high=actual["high"]
except (OSError,ValueError,TypeError): pass
print(json.dumps({"SentinelInstalled":installed,"SentinelIntegrityValid":integrity,"SentinelLaunchDaemonHealthy":runtime,"SentinelReportingConfigured":reporting_configured,"SentinelReportingHealthy":reporting_healthy,"SentinelPolicyVersion":policy,"SentinelReportValid":report_valid,"SentinelScanRecent":recent,"SentinelCriticalFindings":critical,"SentinelHighFindings":high},separators=(",",":")))
PY
