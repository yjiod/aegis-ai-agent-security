#!/usr/bin/env python3
"""Dispatch accepted collector reports through the fail-safe vendor adapter."""
import argparse, hashlib, hmac, importlib.util, json, os, re, sqlite3, time
from contextlib import contextmanager
from pathlib import Path

def load_adapter(path=None):
    path=Path(path or Path(__file__).with_name("sentinel_adapter.py"))
    spec=importlib.util.spec_from_file_location("sentinel_adapter_runtime",path)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def load_vendor_preflight(path=None):
    path=Path(path or Path(__file__).with_name("sentinel_vendor_preflight.py"))
    spec=importlib.util.spec_from_file_location("sentinel_vendor_preflight_runtime",path)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def retention_days(value=None):
    raw=os.getenv("SENTINEL_ADAPTER_DISPATCH_RETENTION_DAYS","90") if value is None else value
    try: return min(max(int(raw),1),3650)
    except (TypeError,ValueError): return 90

def batch_size(value=None):
    raw=os.getenv("SENTINEL_ADAPTER_BATCH_SIZE","50") if value is None else value
    try: return min(max(int(raw),1),500)
    except (TypeError,ValueError): return 50

def poll_seconds(value=None):
    raw=os.getenv("SENTINEL_ADAPTER_POLL_SECONDS","10") if value is None else value
    try: return min(max(float(raw),1),3600)
    except (TypeError,ValueError): return 10

def preflight(config,adapter,acceptance=None,now=None):
    adapter.validate_config(config)
    enabled=0
    for name in adapter.ADAPTERS:
        target=config.get(name,{})
        if not target.get("enabled"): continue
        enabled+=1; adapter.validate_target(name,target,config)
        if name=="sangfor":
            for action in target.get("actions",{}).values():
                if action not in adapter.SAFE_ACTIONS: raise ValueError(f"unsafe_sangfor_action:{action}")
    if not enabled: raise ValueError("no_enabled_adapters")
    blockers=load_vendor_preflight().evaluate(config,acceptance or {},adapter_version="0.15",now=now)
    if blockers: raise ValueError("vendor_acceptance_failed:"+",".join(blockers))

@contextmanager
def open_db(path):
    db=sqlite3.connect(path,timeout=5)
    try:
        db.execute("PRAGMA busy_timeout=5000"); db.execute("PRAGMA journal_mode=WAL")
        db.execute("CREATE TABLE IF NOT EXISTS adapter_dispatches(report_id INTEGER PRIMARY KEY, report_hash TEXT NOT NULL, processed_at INTEGER NOT NULL, result TEXT NOT NULL)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_adapter_dispatch_time ON adapter_dispatches(processed_at)"); db.commit(); yield db
    finally: db.close()

def result_summary(outputs):
    allowed=("adapter","result","status","queue_id","error")
    return [{key:item[key] for key in allowed if key in item} for item in outputs]

def record_rejection(db_path,report_id,report_hash,now,result):
    encoded=json.dumps([{"adapter":"boundary","result":result}],separators=(",",":"))
    with open_db(db_path) as db:
        db.execute("INSERT OR IGNORE INTO adapter_dispatches(report_id,report_hash,processed_at,result) VALUES(?,?,?,?)",(report_id,str(report_hash)[:64],now,encoded)); db.commit()
    return {"report_id":report_id,"result":result}

def dispatch_once(db_path,config,spool,adapter=None,sender=None,limit=None,now=None,acceptance=None):
    adapter=adapter or load_adapter(); now=int(time.time()) if now is None else int(now); preflight(config,adapter,acceptance,now)
    spool=Path(spool); adapter.flush_spool(config,spool,sender=sender or adapter.send)
    with open_db(db_path) as db:
        db.execute("DELETE FROM adapter_dispatches WHERE processed_at < ? AND report_id NOT IN (SELECT id FROM reports)",(now-retention_days()*86400,)); db.commit()
        rows=db.execute("SELECT r.id,COALESCE(r.report_hash,''),length(CAST(r.body AS BLOB)) FROM reports r LEFT JOIN adapter_dispatches d ON d.report_id=r.id WHERE d.report_id IS NULL ORDER BY r.id LIMIT ?",(batch_size(limit),)).fetchall()
    completed=[]
    for report_id,report_hash,body_bytes in rows:
        if isinstance(body_bytes,bool) or not isinstance(body_bytes,int) or body_bytes<0 or body_bytes>adapter.MAX_VENDOR_PAYLOAD_BYTES:
            completed.append(record_rejection(db_path,report_id,report_hash,now,"rejected_oversized_stored_report")); continue
        with open_db(db_path) as db: stored=db.execute("SELECT body FROM reports WHERE id=?",(report_id,)).fetchone()
        if not stored or not isinstance(stored[0],str):
            completed.append(record_rejection(db_path,report_id,report_hash,now,"rejected_invalid_stored_report")); continue
        raw=stored[0].encode("utf-8")
        if len(raw)>adapter.MAX_VENDOR_PAYLOAD_BYTES:
            completed.append(record_rejection(db_path,report_id,report_hash,now,"rejected_oversized_stored_report")); continue
        if not isinstance(report_hash,str) or not re.fullmatch(r"[0-9a-f]{64}",report_hash) or not hmac.compare_digest(hashlib.sha256(raw).hexdigest(),report_hash):
            completed.append(record_rejection(db_path,report_id,report_hash,now,"rejected_stored_report_digest_mismatch")); continue
        try: report=json.loads(stored[0])
        except (TypeError,ValueError,RecursionError):
            completed.append(record_rejection(db_path,report_id,report_hash,now,"rejected_invalid_stored_report")); continue
        outputs=adapter.process(report,config,spool_dir=spool,sender=sender or adapter.send,now=now)
        accepted=bool(outputs) and all(item.get("result") in {"sent","queued"} for item in outputs)
        summary=result_summary(outputs)
        if not accepted: completed.append({"report_id":report_id,"result":"retained","outputs":summary}); continue
        encoded=json.dumps(summary,ensure_ascii=False,separators=(",",":"))
        if len(encoded)>16384: encoded='[{"result":"accepted_result_truncated"}]'
        with open_db(db_path) as db:
            db.execute("INSERT OR IGNORE INTO adapter_dispatches(report_id,report_hash,processed_at,result) VALUES(?,?,?,?)",(report_id,report_hash[:64],now,encoded)); db.commit()
        completed.append({"report_id":report_id,"result":"dispatched","outputs":summary})
    return completed

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--db",default="/var/lib/sentinel/sentinel.db"); ap.add_argument("--config",default="/etc/sentinel/adapters.json"); ap.add_argument("--acceptance",default="/etc/sentinel/vendor-acceptance.json"); ap.add_argument("--spool",default="/var/lib/sentinel/adapter-spool"); ap.add_argument("--once",action="store_true"); args=ap.parse_args()
    adapter=load_adapter()
    try:
        config=adapter.read_json_bounded(args.config,adapter.MAX_VENDOR_CONFIG_BYTES)
        needs_acceptance=any(isinstance(config.get(name),dict) and config[name].get("enabled") for name in ("sangfor","leagsoft"))
        acceptance=adapter.read_json_bounded(args.acceptance,adapter.MAX_VENDOR_ACCEPTANCE_BYTES) if needs_acceptance else None
        preflight(config,adapter,acceptance)
    except (OSError,ValueError,TypeError,RecursionError,UnicodeError,json.JSONDecodeError) as exc: raise SystemExit("invalid adapter worker configuration: "+str(exc))
    while True:
        results=dispatch_once(args.db,config,args.spool,adapter=adapter,acceptance=acceptance)
        if args.once: print(json.dumps(results,ensure_ascii=False,indent=2)); return
        time.sleep(poll_seconds())

if __name__=="__main__": main()
